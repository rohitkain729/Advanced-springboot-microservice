package com.app.model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Student {

	private Integer sno;
	private String sname;
	private String saddn;
	private Float avg;

	@DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime dob;

	private List<String> favColors;
	private String[] friends;
	private Map<String, String> idDetails;
	private Set<Long> phones;

	private Address add;
}