package com.app.controller;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.model.Address;
import com.app.model.Student;

@RestController
@RequestMapping("/student")
public class StudentRestController {

    @PostMapping(value = "/save",
            consumes = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE },
            produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
    public ResponseEntity<Student> registerStudent(@RequestBody Student stu) {
        System.out.println(stu);
        return new ResponseEntity<Student>(stu, HttpStatus.OK);
    }

    @GetMapping(value = "/show",
            produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Student> registerStudent() {

        Address add = new Address()
                .builder()
                .hno("122")
                .landMark("Manhattan square")
                .pincode(343344L)
                .street("ambedkar street")
                .build();

        Student stu = new Student()
                .builder()
                .avg(23.67f)
                .sno(11)
                .sname("rohit")
                .saddn("india")
                .dob(LocalDateTime.of(2024, 11, 2, 4, 12))
                .favColors(List.of("orange", "green"))
                .friends(new String[] { "ashok", "babaji", "ashish" })
                .idDetails(Map.of("pancard", "3434ann", "DrivingLicense", "mp07348729427d"))
                .phones(Set.of(555555551L, 8888888881L))
                .add(add)
                .build();

        return new ResponseEntity<Student>(stu, HttpStatus.OK);
    }
}

